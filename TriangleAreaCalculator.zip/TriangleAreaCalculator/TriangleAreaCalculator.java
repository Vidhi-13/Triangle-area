public class Tri {

  public static void main(String[] args) {
    Point P = new Point(10, 20);
    Point V = new Point(10, 60);
    Point H = new Point(80, 20);
    System.out.println("Area of triangle is: "
        + Triangle.area(P, V, H));
 }
}

class Point {
  int p;
  int q;
  public Point(int p, int q) {
    this.p = p;
    this.q = q;
  }    
}

class Triangle {
  public static float area(Point P, Point V, Point H) {
    float area = (P.p * (V.q - H.q) 
                    + V.p * (H.q - P.q) + H.p * (P.q - V.q)) / 2.0f;
    return Math.abs(area);
  }
}